# iceland-firmware 11.A.38: notices

These files are proprietary firmware of Qualcomm Technologies, Inc. / Qualcomm Atheros, Inc., Novatek Microelectronics
Corp. and OnePlus (OPLUS), as shipped on every OnePlus Pad 4 (OPD2514) in the stock software release 11.A.38. They are
redistributed UNMODIFIED, with these documented, byte-exact transformations only:

- `*.mbn` built from split images: the `.mdt` header file and its `.bNN` segments joined into one ELF (what
  pil-squasher does); every segment is byte-identical to the stock file.
- `novatek_nt36536_fw.bin`: the stock `FwUp!` container's 80-byte header and 128-byte trailer removed; the payload is
  byte-identical.
- `socinfo/*`: SoC identification values (stock `/sys/devices/soc0`), not vendor code.

Since 11.A.38-5 the package also carries stock's GPU GMU firmware and SQE microcode (`gen80200_gmu.bin` v5.3.39,
`gen80200_sqe.fw` 0x103; Qualcomm Technologies, Inc.), byte copies of `vendor_a:/firmware/` of 11.A.38, in
`/usr/lib/firmware/iceland-gpu-stock/qcom/`. They do not replace the copies of Fedora's linux-firmware package, which
keep their own notice (`WHENCE` / `LICENSE.qcom` of linux-firmware); the kernel uses stock's pair only when its
command line has `firmware_class.path=/usr/lib/firmware/iceland-gpu-stock`.

One file is not a byte copy: `/etc/iceland/thermal-model.json`, stock's shell-temperature model (the input of
iceland-thermal), decoded from the vendor's encrypted thermal configuration of 11.A.38. It is generic:
identical on every unit (no serial, address or calibration field); only the models, the gear table and the status
table are kept, as JSON. The encrypted configuration files, the vendor's program, its key and the decoding tool are
not published (`EXCLUDED.tsv`).

Since 11.A.38-6 two files are not from 11.A.38: `/usr/lib/firmware/iceland-gpu-vendor533/qcom/gen80200_gmu.bin`
(GMU v5.3.33) and `gen80200_sqe.fw` (SQE 0x094), Qualcomm Technologies, Inc. Adreno 840 microcode as shipped in
another kaanapali vendor image (Lenovo TB323FU, ZUI 18.0.12.104). They are unmodified copies, byte-identical in
SuperTurtleDev/iceland-mainline-kernel-firmware d0c0f18, map220v/iceland-firmware da6a19a and the TB323FU manifest
of joonhoekim/tb323fu-linux 43ee432; no licence or notice text accompanies them in any of these sources. The kernel
uses them only when its command line names their directory
(`firmware_class.path=/usr/lib/firmware/iceland-gpu-vendor533`).

All rights remain with their owners. No licence is granted beyond the right to use the files with OnePlus Pad 4 hardware
as the owners permit. `Notice-qca-atheros.txt` is Qualcomm Atheros' notice file for the WCN7860 Wi-Fi firmware
(copy from SuperTurtleDev/iceland-mainline-kernel-firmware d0c0f18, sha256 in MANIFEST/README).
Each file's source partition and path in 11.A.38 and its sha256 are in `MANIFEST.tsv`; unit-specific data (calibration,
addresses, persist data) is never part of this package (`EXCLUDED.tsv`).
